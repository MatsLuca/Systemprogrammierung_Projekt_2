/* ------------------------------------------------------------------
 * cleanup.h - Header des Cleanup-Moduls
 * Copyright 2025 Hochschule Hannover
 * Autor: Mats-Luca Dagott
 * ------------------------------------------------------------------ */


#ifndef CLEANUP_H
#define CLEANUP_H

void cleanup_ncurses(void);

#endif /* CLEANUP_H */
